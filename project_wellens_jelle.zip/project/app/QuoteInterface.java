public interface QuoteInterface {
    String text = "";
    void getText();
    void setText();
}
